Configuration iissettingup
{   Import-DscResource -ModuleName xWebAdministration
	param ($MachineName)
	Node $MachineName
	{ 
		WindowsFeature InstallWebServer 
		{ 
			Ensure = "Present"
			Name = "Web-Server" 
		} 
	} 
	xWebsite MainHTTPWebsite  
{  
    Ensure          = "Present"  
    Name            = "Default Web Site"
    State           = "Started"  
    BindingInfo     = @(
                        @(MSFT_xWebBindingInformation   
                            {  
                                Protocol              = "HTTP"
                                Port                  =  80 
                                HostName              = "localhost"
                            }
                        )
                      )
}  
}
