
Configuration ContosoWebsite
{
  param ($MachineName)
  Import-DscResource -ModuleName PsDesiredStateConfiguration
  Import-DscResource -ModuleName xWebAdministration
  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = “Present”
      Name = “Web-Server”
    }
    xWebsite Website
    {
        Name = 'DefaultWebSite'
        BindingInfo = @(
        MSFT_xWebBindingInformation
        {
            Protocol              = 'HTTP' 
            Port                  = '8080'
            IPAddress             = '*'
            HostName              = 'DefaultWebSite'

        }
        )
    }
}
}
