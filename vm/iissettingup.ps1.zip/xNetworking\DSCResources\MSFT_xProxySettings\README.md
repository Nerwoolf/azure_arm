# Description

The resource is used to configure internet proxy settings for a computer.
